<x-layouts.app title="Pasien">
    <h1 class="ml-4">Halo Selamat Datang pasien</h1>
</x-layouts.app>
