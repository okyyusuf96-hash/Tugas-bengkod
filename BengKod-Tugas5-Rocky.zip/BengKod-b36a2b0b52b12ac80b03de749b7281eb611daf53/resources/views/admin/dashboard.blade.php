<x-layouts.app title="Admin Dashboard">
    <h1 class="ml-4">Halo Selamat Datang admin</h1>
</x-layouts.app>
