<footer class="main-footer">
  <strong>Copyright &copy; 2024 <a href="#">Poliklinik 2024</a>.</strong>
  All right reserved.
</footer>
