<x-layouts.app>
    <h1 class="ml-4">Halo Selamat Datang Di Halaman Dokter</h1>
</x-layouts.app>
